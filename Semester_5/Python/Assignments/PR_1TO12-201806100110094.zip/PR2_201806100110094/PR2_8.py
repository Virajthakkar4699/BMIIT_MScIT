#8.To find & display multiplication table of number N.

n=int(input('Enter number '))
for i in range(1,11):
    print(n," * ",i," = ",n*i)

