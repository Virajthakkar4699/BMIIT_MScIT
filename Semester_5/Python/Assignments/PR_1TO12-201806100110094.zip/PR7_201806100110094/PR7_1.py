n=int(input("Enter Number :"));

numbers={}
for i in range(1,n+1):
    numbers[i]=i*i;
print(numbers);
