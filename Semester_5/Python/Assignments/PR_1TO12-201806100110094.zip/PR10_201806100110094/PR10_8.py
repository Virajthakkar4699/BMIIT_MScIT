class Baseclass:
    def basefun(this):
        print("basefun called")
class Derivedclass(Baseclass):
obj=Derivedclass()
obj.basefun()
