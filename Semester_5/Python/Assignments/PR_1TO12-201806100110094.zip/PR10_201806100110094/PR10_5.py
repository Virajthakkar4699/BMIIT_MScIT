class Student:
    def __init__(this):
        print("initialzed")
    def __del__(this):
        print("destroyed")
obj=Student()
del obj
