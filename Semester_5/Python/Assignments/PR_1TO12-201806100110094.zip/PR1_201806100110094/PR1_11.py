num = float(input("Enter a number: "))  
  
if num > 0:  
 print("positive number")  
elif num == 0:  
   print(num,"is zero")   
else:  
   print("negative number")   
