print("hello world")
