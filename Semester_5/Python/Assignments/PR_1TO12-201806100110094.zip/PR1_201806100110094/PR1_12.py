a = float(input(" Please Enter the First Value a: "))
b = float(input(" Please Enter the Second Value b: "))

if(a == b):
    print("Both a and b are Equal")
elif(a>b):
    print(a," is the Largest Value")
else: 
    print(b," is the Largest Value")
