a = float(input(" Please Enter the First Value a: "))
b = float(input(" Please Enter the Second Value b: "))

if(a > b):
    print(a,"Greater than ",b)
elif(b > a):
    print(b,"Greater than ",a)
else:
    print("Both a and b are Equal")
