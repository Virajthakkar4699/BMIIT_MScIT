kilograms = float(input("Please enter kilograms:"))
grams = kilograms * 1000
print(grams, " Grams")
