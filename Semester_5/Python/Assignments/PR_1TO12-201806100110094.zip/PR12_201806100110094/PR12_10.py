result=re.findall(r'\d{2}-\d{2}-\d{4}','parth desai , 25-10-2000')
print("date :",result)