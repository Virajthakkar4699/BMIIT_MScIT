str='viraj ; thakkar,ketan'
result=re.split(r'[;,\s]',str)  
print("split :",result)