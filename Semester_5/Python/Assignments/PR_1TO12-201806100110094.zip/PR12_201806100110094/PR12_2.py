str='abc xyz'
x = re.findall("aiii", str)
print("string : ",x)