result=re.findall(r'\b[AEIOUaeiou]\w+','1 Viraj Thakkar'
print("vovels :",result)