if re.match(r'\d{10}$',input("enter mobile number :")):
    print("number is valid")
else:
    print("number is not valid")