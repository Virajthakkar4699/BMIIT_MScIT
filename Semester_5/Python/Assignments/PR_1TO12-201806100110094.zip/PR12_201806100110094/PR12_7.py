result=re.findall(r'\w\w','viraj thakkar')
print("consecutive character :",result)
