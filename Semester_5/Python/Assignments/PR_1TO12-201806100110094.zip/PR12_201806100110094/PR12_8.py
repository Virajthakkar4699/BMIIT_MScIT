result=re.findall(r'\b\w\w','viraj Thakkar')
print("consecutive character :",result)