if re.match(r'\w+',input("enter string :")):
    print("string contains[A-Za-z0-9]")
else:
    print("string is not valid")