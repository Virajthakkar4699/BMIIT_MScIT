result=re.findall(r'^\w+','Python is a programmimg language')
print("first word :",result)