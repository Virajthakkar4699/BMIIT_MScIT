result=re.findall(r'\w+','91AV is largest Analytics community of India')
result1=re.findall(r'\w*','91AV is largest Analytics community of India')
print("using + :",result)
print("using * :",result1)