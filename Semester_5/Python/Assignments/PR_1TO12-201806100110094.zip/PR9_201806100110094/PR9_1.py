import array as arr 

v = arr.array('i',[10,20,30,40,50])

for a in range(len(v)):
    print(v[a])
