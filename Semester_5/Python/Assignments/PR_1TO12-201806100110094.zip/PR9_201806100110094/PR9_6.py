import array as arr 
v = arr.array('i',[10,20,30,40,50])
a.pop(5)
print(v)
