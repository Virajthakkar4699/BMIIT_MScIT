#5.Create Tuple with Single Element.

t1=(1,)
print(t1)
print(type(t1))
