x=int(input("Enter a number:"))
y=int(input("Enter second number:"))

def cal():
    print("Addition of two number is:",(x+y))
    print("Subtraction of two number is:",abs(x-y))
    print("Multiplication of two number is:",(x*y))
    print("Division of two number is:",(x/y))
cal()