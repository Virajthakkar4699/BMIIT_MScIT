KG=int(input("Enter a kilogram:"))
def converter():
    Gram=KG*1000
    print("Converted value of kilogram to gram is:",Gram)

converter();
