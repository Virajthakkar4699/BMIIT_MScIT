def ASCII_con():
    x=int(input("Enter any ASCII number:"))
    print("The value of ASCII is:",chr(x))
ASCII_con()
