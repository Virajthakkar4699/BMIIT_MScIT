set1={10,20,30,50,40}

set1.difference_update({10,20,30});
print(set1);
