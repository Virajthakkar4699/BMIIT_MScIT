set1={10,20,30,40,50}
set2={50,45,20,35}

set1.difference_update(set2);
print(set1);
