set1={10,20,30,25,45}
set2={30,45,25,65}

set1.intersection_update(set2);
print(set1);
