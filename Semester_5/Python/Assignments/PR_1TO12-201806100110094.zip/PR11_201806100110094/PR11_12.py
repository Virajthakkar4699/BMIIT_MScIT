list1 = ['PARTH','Pooja','PRATIK','Riya','KRUTI','Kishan','VIRAJ','Honey','DEEP','Sourabh']
print("Original: \n",list1)
list1.sort()
print("Sorted : \n",list1)
