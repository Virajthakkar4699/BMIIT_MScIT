var1 = "Hello "
var2 = "World"

var3 = var1 + var2
print(var3)

  
  

