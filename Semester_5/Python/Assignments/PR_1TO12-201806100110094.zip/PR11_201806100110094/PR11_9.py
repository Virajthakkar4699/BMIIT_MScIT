import re
str = "Babu Madhav Institute Of Information Technology"
x = str.count("M")
if(x>=1):
    print("M is present in string")
else:
    print("M is not present in this string")
