word=input("please enter a word : ")
for index,letter in enumerate(word,1):
    print(index,":",letter)
