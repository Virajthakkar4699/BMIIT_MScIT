str = input("enter a string : ")
count = 0
for i in str:
    count = count + 1
print("Length : ",count)
