str = input("Enter string : ")
count = 0
for i in str:
    count = count + 1
print("Length of string is : ",count)
